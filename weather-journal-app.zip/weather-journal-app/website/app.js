
/* Global Variables */
const baseURL ='http://api.openweathermap.org/data/2.5/forecast?id=';
const myapikey='&appid=1d98afecab23f878f3f3baef57a2649b';


// Adding Event Listener
document.getElementById("generate").addEventListener("click", doAction);

// Event listener function
function doAction(){
    const newZip=document.getElementById("zip").value;
    const feeings=document.getElementById("feelings").value;
    getWeather(baseURL, newZip, myapikey).then(function(data){
        console.log(data);
        postData('/add',{date:d,temp:data.list[0].main.temp,content:feelings })
        updateUI();
    })
};

// Function get with api
const getWeather = async (baseURL,zip,key)=>{
    const responce = await fetch(baseURL+zip+key)
    try{
        const data=await responce.json();
        return data;
    }catch(error){
        console.log('error',error);
    }
}

//post function
const updateUI = async (data) => {
    const response = await fetch("/addData", {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    }).then(async (data) => {
      const res = await fetch("/allData");
      try {
        waetherData = await res.json();
        console.log(waetherData);
        document.getElementById("date").innerHTML = waetherData.date;
        document.getElementById("temp").innerHTML = waetherData.temp;
        document.getElementById("content").innerHTML = waetherData.feelings;
      } catch (error) {
        console.log(error);
      }
    });
  };
  
